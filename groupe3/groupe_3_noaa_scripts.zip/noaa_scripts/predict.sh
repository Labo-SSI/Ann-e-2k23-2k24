#!/bin/bash -e

SATELLITE_NAME="$1"
FREQUENCY="$2"

prediction_output=$(predict -p "${SATELLITE_NAME}") # On récupère notre première prédiction

start_prediction=$(echo "$prediction_output" | head -n 1) 
end_prediction=$(echo "$prediction_output" | tail -n 1)

elevation=$(echo "$prediction_output" | awk -v max=0 '{if($5>max){max=$5}}END{print max}') # On récupère le moment où le satellite sera au plus haut

timestamp_end_prediction=$(echo "$end_prediction" | cut -d " " -f 1) # On récupère le timestamp de la dernière ligne de notre prédiction

while [ "$(date --date="TZ=\"UTC\" @${timestamp_end_prediction}" +%D)" == "$(date +%D)" ]; do 
    timestamp_start_prediction=$(echo "${start_prediction}" | cut -d " " -f 1)
    record_time=$(( "${timestamp_end_prediction}" - "${timestamp_start_prediction}"))

    if [ "$elevation" -gt 50 ] 
       then
        print_hour=$(date --date="TZ=\"UTC\" @${timestamp_start_prediction}" +%H:%M)
        echo "[+] Une capture de $SATELLITE_NAME est prévue à $print_hour avec une élévation maximale de $elevation"
        echo "/home/nugget/Documents/satellite_project/backend/scripts/capture.sh \"${SATELLITE_NAME}\" ${FREQUENCY} ${timestamp_start_prediction} ${record_time} ${elevation}" | at "$(date --date="@${timestamp_start_prediction}" +"%H:%M %D")"
    fi

    NEXT_PREDICT=$(( "${timestamp_end_prediction}" + 600 ))

    prediction_output=$(predict -p "${SATELLITE_NAME}" "${NEXT_PREDICT}") 

    start_prediction=$(echo "$prediction_output" | head -n 1) 
    end_prediction=$(echo "$prediction_output" | tail -n 1)

    elevation=$(echo "$prediction_output" | awk -v max=0 '{if($5>max){max=$5}}END{print max}') 
    
    timestamp_end_prediction=$(echo "$end_prediction" | cut -d " " -f 1) 
done