#!/bin/bash -e

SATELLITE_NAME="$1"
FREQUENCY="$2"
TIMESTAMP_PREDICTION_START="$3"
RECORD_TIME="$4"
ELEVATION="$5"

capture_start_time=$(date --date="TZ=\"UTC\" @${TIMESTAMP_PREDICTION_START}" +%Y-%m-%d_%H-%M)
filename="${capture_start_time}_${SATELLITE_NAME//" "}_${ELEVATION}"

data_dir="/home/nugget/Documents/satellite_project/backend/static"
audio_dir="${data_dir}/audio"
wav_file="${audio_dir}/${filename}.wav"
log_file="${data_dir}/../scripts/log.txt"

sudo timeout "${RECORD_TIME}" rtl_fm -f "${FREQUENCY}M" -s 60k -g 45 -p 55 -E deemp -F 9 - | sox -t raw -r 60k -es -b 16 -c 1 - "${wav_file}" rate 11025 2> "${log_file}"

if [ -e "${wav_file}" ]
  then
    map_file="${filename}-map.png"
    pass_start=$(( TIMESTAMP_PREDICTION_START + 90 ))
    wxmap -T "${SATELLITE_NAME}" -a -g 0 -C 0 -p 0 -t 0 -l 0 -o "${pass_start}" "${map_file}" 2> "${log_file}"
    
    image_name="${data_dir}/img/${SATELLITE_NAME//" "}/${filename}"
    # normal infrared
    #wxtoimg -m "${map_file}" -e ZA "${wav_file}" "${image_name}-ZA.png" 2> "${log_file}"
    # map color infrared
    wxtoimg -m "${map_file}" -e MCIR "${wav_file}" "${image_name}-MCIR.png" 2> "${log_file}"
    # thermal
    #wxtoimg -m "${map_file}" -e THERM "${wav_file}" "${image_name}-THERM.png" 2> "${log_file}"

    rm -f "${map_file}"
fi