#!/bin/bash -e

wget -qr https://www.celestrak.com/NORAD/elements/weather.txt -O ~/.wxtoimg/weather.txt # On récupère les TLE du jour
cp ~/.wxtoimg/weather.txt ~/.predict/predict.tle # On met à jour les Keplers de predict

for i in $(atq | awk '{print $1}');do atrm $i;done

/home/nugget/Documents/satellite_project/backend/scripts/predict.sh "NOAA 19" 137.1000 
/home/nugget/Documents/satellite_project/backend/scripts/predict.sh "NOAA 18" 137.9125 
#/home/nugget/Documents/satellite_project/backend/scripts/predict.sh "NOAA 15" 137.6200 